--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Quintor";
--
-- Name: Quintor; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Quintor" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "Quintor" OWNER TO postgres;

\connect "Quintor"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: delete_member(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.delete_member(IN memberid integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM Member WHERE Member.memberID = delete_member.memberID;
END;
$$;


ALTER PROCEDURE public.delete_member(IN memberid integer) OWNER TO postgres;

--
-- Name: get_association(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.get_association()
    LANGUAGE sql
    AS $$
    SELECT * FROM Association;
$$;


ALTER PROCEDURE public.get_association() OWNER TO postgres;

--
-- Name: insert_into_association(character varying, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_into_association(IN association_id character varying, IN association_name character varying, IN association_password character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO Association (accountID, name, password) VALUES (association_id, association_name, association_password);
END;
$$;


ALTER PROCEDURE public.insert_into_association(IN association_id character varying, IN association_name character varying, IN association_password character varying) OWNER TO postgres;

--
-- Name: insert_into_file(character varying, character varying, character varying, real, real, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_into_file(IN reference_number character varying, IN statement_number character varying, IN sequence_detail character varying, IN available_balance real, IN forward_avbalance real, IN account_id character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO File (referenceNumber, statementNumber, sequenceDetail, availableBalance,forwardAvBalance,accountID) VALUES (reference_Number, statement_Number, sequence_Detail, available_Balance,forward_AvBalance,account_ID);
END;
$$;


ALTER PROCEDURE public.insert_into_file(IN reference_number character varying, IN statement_number character varying, IN sequence_detail character varying, IN available_balance real, IN forward_avbalance real, IN account_id character varying) OWNER TO postgres;

--
-- Name: insert_into_member(character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_into_member(IN name character varying, IN email character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO Member (name, email) VALUES (name,email);
END;
$$;


ALTER PROCEDURE public.insert_into_member(IN name character varying, IN email character varying) OWNER TO postgres;

--
-- Name: insert_into_transaction(character varying, character varying, character varying, double precision, character varying, character varying, integer, integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_into_transaction(IN referencenumber character varying, IN transactiondetail character varying, IN description character varying, IN amount double precision, IN currency character varying, IN transaction_date character varying, IN categoryid integer, IN memberid integer, IN typetransaction character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO Transactions (referenceNumber, transactionDetail, description, amount,currency,transaction_date,categoryID,memberID,typeTransaction) VALUES (referenceNumber, transactionDetail, description, amount,currency,transaction_date,categoryID,memberID,typeTransaction);
END;
$$;


ALTER PROCEDURE public.insert_into_transaction(IN referencenumber character varying, IN transactiondetail character varying, IN description character varying, IN amount double precision, IN currency character varying, IN transaction_date character varying, IN categoryid integer, IN memberid integer, IN typetransaction character varying) OWNER TO postgres;

--
-- Name: select_all_association(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.select_all_association() RETURNS TABLE(accountid character varying, name character varying, password character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY SELECT Association.accountID, Association.name, Association.password FROM Association;
END;
$$;


ALTER FUNCTION public.select_all_association() OWNER TO postgres;

--
-- Name: select_all_file(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.select_all_file() RETURNS TABLE(referencenumber character varying, statementnumber character varying, sequencedetail character varying, availablebalance real, forwardavbalance real, accountid character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY SELECT File.referenceNumber, File.statementNumber , File.sequenceDetail , File.availableBalance , File.forwardAvBalance , File.accountID  FROM File;
END;
$$;


ALTER FUNCTION public.select_all_file() OWNER TO postgres;

--
-- Name: select_all_member(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.select_all_member() RETURNS TABLE(memberid integer, name character varying, email character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY SELECT Member.memberID, Member.name, Member.email FROM Member;
END;
$$;


ALTER FUNCTION public.select_all_member() OWNER TO postgres;

--
-- Name: select_all_transaction(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.select_all_transaction() RETURNS TABLE(transactionid integer, referencenumber character varying, transactiondetail character varying, description character varying, amount double precision, currency character varying, transaction_date character varying, categoryid integer, memberid integer, typetransaction character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY SELECT Transactions.transactionID , Transactions.referenceNumber, Transactions.transactionDetail,
  						Transactions.description , Transactions.amount, Transactions.currency, Transactions.transaction_date, 
						Transactions.categoryID , Transactions.memberID , Transactions.typeTransaction   FROM Transactions;
END;
$$;


ALTER FUNCTION public.select_all_transaction() OWNER TO postgres;

--
-- Name: select_join(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.select_join() RETURNS TABLE(transactionid integer, referencenumber character varying, transactiondetail character varying, description character varying, amount double precision, currency character varying, transaction_date character varying, categoryid integer, memberid integer, typetransaction character varying, member_id integer, name character varying, email character varying, category_id integer, na_me character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY SELECT * 
FROM Transactions FULL OUTER JOIN member
ON Transactions.memberID = Member.memberID
FULL OUTER JOIN Category
ON Category.categoryID = Transactions.categoryID;
END;
$$;


ALTER FUNCTION public.select_join() OWNER TO postgres;

--
-- Name: select_member(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.select_member() RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
DECLARE
    rec record;
BEGIN
    FOR rec IN SELECT memberID, name, email FROM public.Member
    LOOP
        -- return each row of the result set
        RETURN NEXT rec;
    END LOOP;
END;
$$;


ALTER FUNCTION public.select_member() OWNER TO postgres;

--
-- Name: test_select(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.test_select()
    LANGUAGE sql
    AS $_$CREATE OR REPLACE PROCEDURE add_new_member(
	new_part_name varchar,
	new_vendor_name varchar
) 
AS $$
DECLARE
	v_part_id INT;
	v_vendor_id INT;
BEGIN
	-- insert into the parts table
	INSERT INTO Member(name,email) 
	VALUES(new_part_name,new_vendor_name) 
	
END;
$$
LANGUAGE PLPGSQL;$_$;


ALTER PROCEDURE public.test_select() OWNER TO postgres;

--
-- Name: update_transaction(integer, character varying, integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.update_transaction(IN p_transactionid integer, IN p_description character varying, IN p_categoryid integer, IN p_memberid integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE Transactions
    SET 
        description = p_description,
        categoryID = p_categoryID,
        memberID = p_memberID
    WHERE 
        transactionID = p_transactionID;
END;
$$;


ALTER PROCEDURE public.update_transaction(IN p_transactionid integer, IN p_description character varying, IN p_categoryid integer, IN p_memberid integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: association; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.association (
    accountid character varying(35) NOT NULL,
    name character varying(50) NOT NULL,
    password character varying(256) NOT NULL
);


ALTER TABLE public.association OWNER TO postgres;

--
-- Name: category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category (
    categoryid integer NOT NULL,
    name character varying(32)
);


ALTER TABLE public.category OWNER TO postgres;

--
-- Name: category_categoryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.category_categoryid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_categoryid_seq OWNER TO postgres;

--
-- Name: category_categoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.category_categoryid_seq OWNED BY public.category.categoryid;


--
-- Name: file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file (
    referencenumber character varying(16) NOT NULL,
    statementnumber character varying NOT NULL,
    sequencedetail character varying NOT NULL,
    availablebalance real NOT NULL,
    forwardavbalance real NOT NULL,
    accountid character varying(35) NOT NULL
);


ALTER TABLE public.file OWNER TO postgres;

--
-- Name: member; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.member (
    memberid integer NOT NULL,
    name character varying(32) NOT NULL,
    email character varying(254) NOT NULL
);


ALTER TABLE public.member OWNER TO postgres;

--
-- Name: member_memberid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.member_memberid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.member_memberid_seq OWNER TO postgres;

--
-- Name: member_memberid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.member_memberid_seq OWNED BY public.member.memberid;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    transactionid integer NOT NULL,
    referencenumber character varying(16),
    transactiondetail character varying,
    description character varying(128),
    amount double precision NOT NULL,
    currency character varying(3) NOT NULL,
    transaction_date character varying(10),
    categoryid integer,
    memberid integer,
    typetransaction character varying
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: transactions_transactionid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transactions_transactionid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transactions_transactionid_seq OWNER TO postgres;

--
-- Name: transactions_transactionid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transactions_transactionid_seq OWNED BY public.transactions.transactionid;


--
-- Name: category categoryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category ALTER COLUMN categoryid SET DEFAULT nextval('public.category_categoryid_seq'::regclass);


--
-- Name: member memberid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member ALTER COLUMN memberid SET DEFAULT nextval('public.member_memberid_seq'::regclass);


--
-- Name: transactions transactionid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions ALTER COLUMN transactionid SET DEFAULT nextval('public.transactions_transactionid_seq'::regclass);


--
-- Data for Name: association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.association (accountid, name, password) FROM stdin;
\.
COPY public.association (accountid, name, password) FROM '$$PATH$$/3364.dat';

--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category (categoryid, name) FROM stdin;
\.
COPY public.category (categoryid, name) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.file (referencenumber, statementnumber, sequencedetail, availablebalance, forwardavbalance, accountid) FROM stdin;
\.
COPY public.file (referencenumber, statementnumber, sequencedetail, availablebalance, forwardavbalance, accountid) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: member; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.member (memberid, name, email) FROM stdin;
\.
COPY public.member (memberid, name, email) FROM '$$PATH$$/3368.dat';

--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (transactionid, referencenumber, transactiondetail, description, amount, currency, transaction_date, categoryid, memberid, typetransaction) FROM stdin;
\.
COPY public.transactions (transactionid, referencenumber, transactiondetail, description, amount, currency, transaction_date, categoryid, memberid, typetransaction) FROM '$$PATH$$/3370.dat';

--
-- Name: category_categoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.category_categoryid_seq', 1, true);


--
-- Name: member_memberid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.member_memberid_seq', 7, true);


--
-- Name: transactions_transactionid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactions_transactionid_seq', 1, true);


--
-- Name: association association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.association
    ADD CONSTRAINT association_pkey PRIMARY KEY (accountid);


--
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pkey PRIMARY KEY (categoryid);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (referencenumber);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (memberid);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transactionid);


--
-- Name: file file_accountid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_accountid_fkey FOREIGN KEY (accountid) REFERENCES public.association(accountid);


--
-- Name: transactions transactions_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_categoryid_fkey FOREIGN KEY (categoryid) REFERENCES public.category(categoryid);


--
-- Name: transactions transactions_memberid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_memberid_fkey FOREIGN KEY (memberid) REFERENCES public.member(memberid);


--
-- Name: transactions transactions_referencenumber_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_referencenumber_fkey FOREIGN KEY (referencenumber) REFERENCES public.file(referencenumber);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO myuser;


--
-- Name: TABLE association; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.association TO myuser;


--
-- Name: TABLE file; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.file TO myuser;


--
-- Name: TABLE transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.transactions TO myuser;


--
-- PostgreSQL database dump complete
--

